# 혈 송신 형식

혈 Pi가 심 서버(전시컴)로 보내는 데이터의 형식과, Pi 없이 시험해 볼 수 있는 1분 예시를 담았습니다.

## 들어 있는 것

| 파일 | 내용 |
|---|---|
| `SEND_FORMAT.md` | 이 문서 |
| `sample/stream.bin` | 실제 Pi가 보내는 바이트를 그대로 담은 1분 녹화(83 MB). ToF 479장 · 천장 거리 2,783개 |
| `sample/preview.mp4` | 위 1분의 깊이 미리보기(가까울수록 밝음, 신뢰도 30 미만은 검정) |
| `replay_send.py` | Pi 대신 `stream.bin`을 기록된 간격대로 TCP로 보내는 재생기(표준 라이브러리만 사용) |
| `receive_example.py` | 받는 쪽 예시. 초당 개수와 마지막 천장 거리를 출력(numpy 필요) |
| `collector_protocol.py` | 메시지를 읽고 쓰는 함수(`recv` · `pack`). Pi 쪽과 같은 파일 |

## 바로 해 보기

```bash
python3 receive_example.py --port 9500          # 창 1: 받는 쪽
python3 replay_send.py --host 127.0.0.1 --port 9500   # 창 2: Pi 대신 보내기(1분 반복)
```

받는 쪽에 `ToF 10/s · 천장 47/s · 천장 2091 mm` 같은 줄이 2초마다 찍히면 정상입니다.

## 연결

- **방향**: Pi가 TCP 클라이언트로 접속하고, 심 서버는 포트를 열고 기다립니다(기본 9500).
- **주소**: Pi의 `run/send.json`에 `host`(전시컴 IP)와 `port`를 넣습니다. 재시작 없이 1초 안에 반영됩니다.
- **재접속**: 연결이 끊기면 Pi가 2초마다 다시 접속합니다. 새로 연결될 때마다 `hello`부터 다시 보냅니다.
- **보내는 빈도**: 기본 ToF 초당 10장, 천장 거리 초당 50개입니다(`send.json`의 `tof_hz` · `lidar_hz`, 0이면 받는 대로 전부, ToF는 최대 약 30장). 밀리면 최신 것만 보냅니다.

## 메시지 구조

모든 메시지는 같은 틀입니다. 리틀 엔디언입니다.

```
[header 길이: u32][payload 길이: u32][header: UTF-8 JSON][payload: 바이너리]
```

`header.type`이 `hello` · `tof` · `lidar` 중 하나입니다. 모르는 type은 건너뛰면 됩니다. 시각(`*_ns`)은 모두 Pi 기준 나노초 정수입니다. 간격 계산에는 `t_mono_ns`(단조 시계)를, 실제 시각에는 `t_wall_ns`(유닉스 시각)를 씁니다.

### hello — 연결 직후 한 번

```json
{"type":"hello","version":1,
 "tof":{"width":240,"height":180,
        "intrinsics":{"fx":190.92,"fy":191.25,"cx":120.0,"cy":90.0},
        "range_mm":4000,"camera":"Arducam ToF (ArducamDepthCamera SDK)"},
 "lidar":{"model":"TOFSense"},
 "rotate":180}
```

- `rotate`: 카메라가 달린 방향 때문에 이 각도(시계 방향)만큼 돌려야 바로 선 영상이 됩니다. **Pi는 돌리지 않고 원본 그대로 보냅니다.**
- `intrinsics`: 깊이를 3차원 점으로 바꿀 때 씁니다(돌리기 전 원본 좌표 기준). `X = (u − cx) · Z / fx`, `Y = (v − cy) · Z / fy`, `Z = depth`.

### tof — 깊이 한 장

```json
{"type":"tof","seq":10412,"t_wall_ns":1794306973…,"t_mono_ns":337…,
 "width":240,"height":180,"depth_dtype":"<u2","conf_dtype":"<u2"}
```

payload = 깊이 다음에 신뢰도. 각각 `height × width`개의 u16, 행 우선입니다(240 × 180 × 2 바이트 × 2 = 172,800 바이트).

- **depth**: mm. 0은 측정 없음.
- **confidence**: 0~255(u16에 담김). 클수록 믿을 만합니다.

```python
px = h["width"] * h["height"]
depth = np.frombuffer(b, "<u2", px).reshape(h["height"], h["width"])
conf  = np.frombuffer(b, "<u2", px, px * 2).reshape(h["height"], h["width"])
```

### lidar — 천장 거리 한 번

```json
{"type":"lidar","seq":16600,"t_wall_ns":…,"t_mono_ns":…,"sensor_ms":1720456,
 "distance_mm":2091,"status":1,"strength":33900,"id":0,"valid":true}
```

천장을 향한 단일 점 거리 센서입니다. `valid`가 false면(또는 `status` 255) 그 값은 버립니다.

## 해석할 때 주의

- **신뢰도 30 미만 깊이는 실제 값이 아닙니다.** 500 · 1000 · 3000 · 3500 mm 같은 고정값으로 채워져 나옵니다. `conf >= 30`(되도록 60 이상)인 화소만 쓰세요.
- 걸러 내면 빈 공간에서는 화면의 약 2%만 남습니다. 사람이 0.2~1.5 m 안으로 들어와야 화면 대부분이 채워집니다. 혈 화면도 이 기준으로 그립니다.
- 멈춰 있는 화소의 깊이 흔들림은 약 ±24 mm(표준편차)입니다.
- 천장 거리는 평소 약 2.09 m이고, 사람이 아래로 지나가면 짧아집니다.

## 예시 데이터

- 11월 10일 현장 시험 5분 원본 가운데 변화가 가장 큰 1분(실제 59초)을 골랐습니다.
- 시작 후 10초 무렵 손이 잠깐 지나가고, 40초부터 끝까지 약 17초 동안 사람이 센서 가까이에서 움직이며 화면을 채웁니다. 나머지는 빈 공간입니다. 5분 원본 대부분이 빈 공간이라, 1분 내내 움직임이 이어지는 구간은 없었습니다.
- 빈도는 실제 기본 설정(ToF 10 · 천장 50)과 같은 규칙으로 솎았습니다. 원본 프레임이 빠진 몇 초가 있어 ToF는 평균 초당 약 8장입니다.
