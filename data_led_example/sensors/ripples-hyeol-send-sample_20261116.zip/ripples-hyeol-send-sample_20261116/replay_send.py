#!/usr/bin/env python3
"""혈 Pi 대신 보내기: stream.bin(실제 Pi 가 보내는 바이트 그대로)을 기록된 시간 간격대로 TCP 로 보낸다. 끝나면 처음부터 반복.
   python replay_send.py [--host 127.0.0.1] [--port 9500] [--file sample/stream.bin] [--once]
표준 라이브러리만 쓴다. 받는 쪽(심 서버)을 먼저 켜 두면 된다. 연결이 끊기면 2초 뒤 다시 붙는다(hello 부터 다시 보냄 — 실제 sender.py 와 같음)."""
import argparse, json, socket, struct, time
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument("--host", default="127.0.0.1"); ap.add_argument("--port", type=int, default=9500)
ap.add_argument("--file", default=str(Path(__file__).resolve().parent / "sample" / "stream.bin"))
ap.add_argument("--once", action="store_true", help="한 번만 보내고 끝냄")
a = ap.parse_args()

PREFIX = struct.Struct("<II")
msgs = []  # (header dict, raw message bytes)
data = Path(a.file).read_bytes(); i = 0
while i < len(data):
    hl, pl = PREFIX.unpack_from(data, i)
    h = json.loads(data[i + 8:i + 8 + hl]); msgs.append((h, data[i:i + 8 + hl + pl])); i += 8 + hl + pl
hello, body = msgs[0][1], msgs[1:]
t0 = body[0][0]["t_mono_ns"]
print(f"{len(body)}개 메시지 · {(body[-1][0]['t_mono_ns'] - t0) / 1e9:.1f}초 → {a.host}:{a.port}", flush=True)

while True:
    try:
        s = socket.create_connection((a.host, a.port), timeout=2)
        s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        print("연결됨", flush=True); s.sendall(hello)
        while True:
            start = time.monotonic()
            for h, m in body:
                wait = (h["t_mono_ns"] - t0) / 1e9 - (time.monotonic() - start)
                if wait > 0: time.sleep(wait)
                s.sendall(m)
            print("한 바퀴 끝", flush=True)
            if a.once: raise SystemExit
    except OSError as exc:
        print("연결 안 됨/끊김:", exc, "— 2초 뒤 다시", flush=True); time.sleep(2)
